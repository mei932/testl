<?php $__env->startSection("title", "Dashboard"); ?>
<?php $__env->startSection("content"); ?>
<div class="container mt-5">
    <p class="text-center">Xin chào, <?php echo e(Auth::user()->name); ?>!</p>
    <h2 class="text-center mb-4">Thống kê hệ thống</h2>
    <div class="row text-center">
        <div class="col-md-6 mb-3">
            <div class="card p-4 shadow">
                <h5>Tổng số người dùng</h5>
                <h2><?php echo e($userCount); ?></h2>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="card p-4 shadow">
                <h5>Tổng lượt đăng nhập</h5>
                <h2><?php echo e($loginCount); ?></h2>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-12">
            <h3 class="text-center mb-4">Biểu đồ thống kê</h3>
            <canvas id="statsChart" height="100"></canvas>
        </div>
    </div>
    <div class="text-center my-4">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Đăng xuất</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('statsChart').getContext('2d');
    const statsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Người dùng', 'Lượt đăng nhập'],
            datasets: [{
                label: 'Thống kê hệ thống',
                data: <?php echo json_encode([$userCount, $loginCount], 512) ?>,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 99, 132, 0.6)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.default", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/ngocphuc/php/testl/resources/views/welcome.blade.php ENDPATH**/ ?>